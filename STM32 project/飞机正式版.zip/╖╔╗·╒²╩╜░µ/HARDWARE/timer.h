#ifndef __TIMER_H
#define __TIMER_H
#include "sys.h"
#include "delay.h"
#include "Echo.h"
#include "LED.h"
//void TIM5_CH1_Cap_Init(u32 arr,u16 psc);
//void TIM4_Init(u32 arr,u32 psc);

#endif


