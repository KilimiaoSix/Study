#ifndef __TIM_H
#define __TIM_H
#include "sys.h"
extern int hour,minute,second;
void TIM3_Int_Init(u16 arr,u16 psc);


#endif



