#ifndef __LED_H
#define __LED_H

#define LED0 PBout(10)
#define LED1 PBout(12)
#define LED2 PBout(13)
#define LED3 PBout(14)
#define LED4 PBout(11)
#include "sys.h"
void LED_Init(void);
#endif




