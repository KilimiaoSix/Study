#ifndef __MAIN_H
#define __MAIN_H

#include "sys.h"
#include "usart.h"
#include "SHT21.h"
#include "Switch.h"
#include "delay.h"
#include "miniMIU.h"
#include "sys.h"
#include "InPutSwitch.h"
#include "TIM.h"
#include "PWM.h"
#include "mode.h"


#endif


