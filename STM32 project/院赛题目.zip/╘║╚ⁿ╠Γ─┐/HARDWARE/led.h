#ifndef __LED_H
#define __LED_H
#include "sys.h"
#include "delay.h"
#define LED0 PFout(9)
#define LED1 PFout(10)
void LED_Init(void);


#endif







