#ifndef __EXTI_H
#define __EXTI_H
#include "sys.h"
void EXTIX_Init(void);
extern int i;


#endif




