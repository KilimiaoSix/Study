#ifndef __TIM_H
#define __TIM_H
#include "sys.h"
void TIM4_Init(u32 arr,u32 psc);

void TIM5_Init(u32 arr,u32 psc);





#endif 




