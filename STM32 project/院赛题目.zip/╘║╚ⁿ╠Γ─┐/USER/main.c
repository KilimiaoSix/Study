#include "key.h"
#include "exti.h"
#include "pwm.h"
#include "led.h"
#include "adc.h"
#include "sys.h"
#include "usart.h"
#include "lcd.h"
#include "FONT.H"
#include "tim.h"

int main(void)
{
   float cycle=0;
   u8 tbuf[40];
   float Duty_cycle1,Duty_cycle2;
   u16 adc1=0,adc2=0;
   double temp1,temp2;
   NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
   delay_init(168);
   uart_init(115200);
   LED_Init();
   LCD_Init();
   POINT_COLOR=RED;	  
	LCD_ShowString(30,40,210,24,24,"Explorer STM32F4");	
	LCD_ShowString(30,70,200,16,16,"TFTLCD TEST");
	LCD_ShowString(30,90,200,16,16,"Fu Zhou University");
   LCD_ShowString(30,110,200,16,16,"IT Department");      					 
   LCD_ShowString(30,150,200,12,12,"2018/3/17");      
   LCD_ShowString(30,180,200,16,16,"Xie Jiawei");
   LCD_ShowString(30,210,200,16,16,"My name is van");
   delay_ms(1000);
   LCD_Clear(WHITE);
   EXTIX_Init();
   My_ADC1_Init();
   My_ADC2_Init();
   TIM4_Init(9999,8399);
   TIM5_Init(99,8399);
   
   PWM1_Init(10000-1,168-1);
   PWM2_Init(10000-1,168-1);
   LED_Change_Init(500-1,168-1);
   arr1=10000;
   arr2=10000;
   led_arr=500;
   TIM_SetCompare1(TIM10,0);
   TIM_SetCompare1(TIM11,0);
   frequency1=1000000/arr1;
   frequency2=1000000/arr2;
   while(1)
   {
      adc1=Get_Adc1_Average(ADC_Channel_5,20);
      adc2=Get_Adc2_Average(ADC_Channel_6,20);
      temp1=(float)adc1*(3.3/4096);
      temp2=(float)adc2*(3.3/4096);
      ADC_Compare(temp1,temp2); 
      cycle=led_arr*10*0.001;
      Duty_cycle1=((float)pwm1val/arr1)*100;
      Duty_cycle2=((float)pwm2val/arr2)*100;
      delay_ms(10);
      switch(i)
      {
         case 1:
         {
            LCD_ShowString(30,30,210,16,16,"PWM1 OFF");
            sprintf((char*)tbuf,"PWM1 Frequency:%d Hz",0);
            LCD_ShowString(30,50,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM1 Dutycycle:%d%%",0);
            LCD_ShowString(30,70,210,16,16,tbuf);
            LCD_ShowString(30,90,210,16,16,"PWM2 OFF");
            sprintf((char*)tbuf,"PWM2 Frequency:%d Hz",0);
            LCD_ShowString(30,110,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM2 Dutycycle:%d%%",0);
            LCD_ShowString(30,130,210,16,16,tbuf);
         }break;
         case 2:
         {
            LCD_ShowString(30,30,210,16,16,"PWM1 ON");
            sprintf((char*)tbuf,"PWM1 Frequency:%d Hz",(int)frequency1);
            LCD_ShowString(30,50,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM1 Dutycycle:%d%%",(int)Duty_cycle1);
            LCD_ShowString(30,70,210,16,16,tbuf);
            LCD_ShowString(30,90,210,16,16,"PWM2 OFF");
            sprintf((char*)tbuf,"PWM2 Frequency:%1d Hz",0);
            LCD_ShowString(30,110,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM2 Dutycycle:%2d%%",0);
            LCD_ShowString(30,130,210,16,16,tbuf);              
         }break;                                                           
         case 3:
         {
            LCD_ShowString(30,30,210,16,16,"PWM1 OFF");
            sprintf((char*)tbuf,"PWM1 Frequency:%d Hz",0);
            LCD_ShowString(30,50,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM1 Dutycycle:%d%%",0);
            LCD_ShowString(30,70,210,16,16,tbuf);
            LCD_ShowString(30,90,210,16,16,"PWM2 ON");
            sprintf((char*)tbuf,"PWM2 Frequency:%d Hz",(int)frequency2);
            LCD_ShowString(30,110,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM2 Dutycycle:%d%%",(int)Duty_cycle2);
            LCD_ShowString(30,130,210,16,16,tbuf); 
         }break;
         case 0:
         {
            LCD_ShowString(30,30,210,16,16,"PWM1 ON");
            sprintf((char*)tbuf,"PWM1 Frequency:%d Hz",(int)frequency1);
            LCD_ShowString(30,50,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM1 Dutycycle:%d%%",(int)Duty_cycle1);
            LCD_ShowString(30,70,210,16,16,tbuf);
            LCD_ShowString(30,90,210,16,16,"PWM2 ON");
            sprintf((char*)tbuf,"PWM2 Frequency:%d Hz",(int)frequency2);
            LCD_ShowString(30,110,210,16,16,tbuf);
            sprintf((char*)tbuf,"PWM2 Dutycycle:%d%%",(int)Duty_cycle2);
            LCD_ShowString(30,130,210,16,16,tbuf);
         }break;
         
      }
         sprintf((char*)tbuf,"LED Cycle:%f",cycle);
         LCD_ShowString(30,150,210,16,16,tbuf);
      LED0=!LED0;
   }
}




