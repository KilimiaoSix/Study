#ifndef __LED_H
#define __LED_H

#include "sys.h"
#include "delay.h"

#define LED0 PAout(12)
#define LED1 PAout(15)

void LED_Init(void);




#endif



