#ifndef __MAIN_H
#define __MAIN_H
#include "sys.h"
#include "control.h"
#include "delay.h"
#include "usart.h"
#include "led.h"
#include "encoder.h"
#include "motor.h"
#include "wave.h"
extern float pitch,roll,yaw;
extern short gyrox,gyroy,gyroz;
extern short aacx,aacy,aacz;





#endif



