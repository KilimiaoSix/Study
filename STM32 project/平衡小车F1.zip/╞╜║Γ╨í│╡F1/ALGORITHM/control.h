#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"
#include "pid.h"
#include "math.h"
#include "motor.h"
#include "mpu6050.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#define LOW_Speed 45
#define HIGH_Speed 115

#define MIDDLE_VAL 3

#define DirForward 1
#define DirBack -1
#define DirNo 0

#define TurnDir_Left -1
#define TurnDir_Right 1
#define TurnDir_No 0

#define DIFFERENCE 100
extern int Obstacle_avoidance;
extern u8 Flag_sudu,Flag_Stop; //����ң����صı���
extern int Turn_Dir;
extern int Encoder_Left,Encoder_Right;             //���ұ��������������
extern int Balance_Pwm,Velocity_Pwm,Turn_Pwm;
extern int Moto1,Moto2; 
extern int Dir;

void Cotrol(PIDTypeDef *pV,PIDTypeDef *pDir,PIDTypeDef *pAngle);
#endif


